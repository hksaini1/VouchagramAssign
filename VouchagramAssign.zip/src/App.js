import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Route, BrowserRouter, Switch, Redirect } from "react-router-dom";
// import CollegeDetails from './components/Colleges/CollegeDetails.jsx';
import { Home } from './components/Home';

function App() {
  return (
    <div className="App">
    <BrowserRouter>
      <Switch>
        <Route
         exact
         path="/"
        ><Home/>
        </Route>
         {/* <Route
         exact
         path="/collegeDetails"
        ><CollegeDetails/>
        </Route> */}
      </Switch>

    </BrowserRouter>
     
    </div>
  );
}

export default App;
