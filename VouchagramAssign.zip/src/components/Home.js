import React, { Component } from 'react'
import Axios from 'axios';
import LoadProduct from './loadProducts'

export class Home extends Component {
    constructor(){
        super();
        this.state={
            Data:[],
            Seemore:true,
            FetchedData:[]
        }
    }

    getCategory = async() =>{
        try{
            const response =await Axios.get('https://testing.pogo91.com/api/online-store/category/?store_prefix=cake-shop');
            console.log("response",response);
            if(response.data){
                const Data=response.data.category
                console.log("Data",Data);
                this.setState({
                    Data
                })
            }
            else{
                console.log('Data not found');
            }
        }
        catch(e){
            console.log(e);
        }
    }

    seeMore = () =>{
        this.setState({
            Seemore:!this.state.Seemore
        })
        if(this.state.Seemore){
            document.getElementById("UL").classList.add('flex-wrap');
        }
        else{
            document.getElementById("UL").classList.remove('flex-wrap');
        }
    }
    componentDidMount(){
        this.getCategory();
    }
    onClickHandler = async(id) =>{
        try{
            const response=await Axios.get(`https://testing.pogo91.com/api/online-store/category/product/?store_prefix=cake-shop&page=1&category_id=${id}`);
            if( response.data){
                this.setState({
                    FetchedData:response.data.products
                })
            }
            else{
                console.log('Data not found');
            }
        }
        catch(e){
            console.log(e);
        }
    }
    render() {
        console.log("State##",this.state.Data);
        return (
            <div className="main">
                <div >
                <div className="header" style={{padding:"20px"}}><h5 className="category">CATEGORIES</h5> <a className="see_more" onClick={this.seeMore}>{this.state.Seemore?'SEE MORE':'SEE LESS'}</a></div>
                <div>
                    <ul id="UL" className="list-unstyled d-flex  mt-3">
                    {this.state.Data?this.state.Data.map((data)=>{
                        return(
                            
                        <li className="category " onClick={()=>this.onClickHandler(data.id)}>
                        <a href="#">
                            <div className="image" style={{backgroundColor: "rgb(109, 224, 148)"}}>
                                {data.image===""?<span>H</span>:<img src={data.image}/>}
                            </div>
                            <h3>{data.name}</h3>
                        </a>
                    </li>)
                    }):""}
                    </ul>
                </div>
                <LoadProduct Data={this.state.FetchedData}/>
            </div>
            </div>
        )
    }
}

export default Home
