import React from 'react';

export default function LoadProduct(props){
    console.log("props",props);
return(
    <div>
        
        {props.Data?props.Data.map((data)=>{
            return(
                <div class="product_item d-flex">
            <div class="p_i_image ">
                <div class="p_off">0 %</div>
                    <img src={data.image_url}/>
                </div>
                    <div class="p_i_content">
                        <h4>{data.product_name}</h4>
                            <div class="varient_div ">
                                <span class="individual_varient">{data.price_stock[0].name}</span>
                            </div>
                            <div class="p_price">
                          
                                <div>
                                    <span class="old">{`₹ ${data.price_stock[0].mrp}`}</span>
                                    <span class="new">{`₹ ${data.price_stock[0].selling_price}`}</span>
                                </div>
                            </div>
                        </div>
                        <div class="p_add_to_cart"> 
                            <a class="addToCart">Add <span class="plus_icon"></span>
                            </a>
                        </div>
                    </div>
            )
            
        }):'No Data Found'}
    </div>
)

}